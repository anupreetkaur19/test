
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
public class Player {
    
    public static void main(String[] args) {
    }        
    
    String PlayerID;
    String PlayerName;
    Scanner in = new Scanner(System.in);
    
    Player(){
        PlayerID = "P###";
        PlayerName = "Unknown";
    }
    
    Player(String PlayerID, String PlayerName){
        this.PlayerID = PlayerID;
        this.PlayerName = PlayerName;
    }
    
    Player(Player anotherPlayer){
        this.PlayerID = anotherPlayer.PlayerID;
        this.PlayerName = anotherPlayer.PlayerName;
    }
    
    void setPlayerID(){
        System.out.println("Enter Player's ID");
        this.PlayerID = in.nextLine();
    }
    
    String getPlayerID(){
        return this.PlayerID;
    }
    void setPlayerName(){
        System.out.println("Enter Player's Name");
        this.PlayerName = in.nextLine();
    }
    
    String getPlayerName(){
        return this.PlayerName;
    }
    
    @Override
    public String toString(){
        String data = "PlayerID : " + "\n PlayerName :" + PlayerName;
    return data;
    }}
