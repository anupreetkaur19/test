
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
public class playerstatistics {
    static int bowlerCount = 0;
    static int batsmenCount = 0;
    public static void main(String []args){
        Scanner scn = new Scanner(System.in);
        Bowler []bowlers = new Bowler[2];
        Batsman []batsmen = new Batsman[2];
        for (int i = 0; i<4; i++){
            System.out.println("Enter the type of player: ");
            String choice = scn.nextLine();
            if (choice.equalsIgnoreCase("Bowler")){
                Bowler bowler = new Bowler();
                bowler.readData();
                bowlers[bowlerCount] = bowler;
                bowlerCount++;
            }
            else if (choice.equalsIgnoreCase("Batsman")){
                Batsman batsman = new Batsman();
                batsman.readData();
                batsmen[batsmenCount] = batsman;
                batsmenCount++;
            }
        }
        for (Bowler bowler : bowlers) {
            Bowler bowl = (Bowler) bowler;
            System.out.println(bowl.toString());
        }
        for (Batsman batsmen1 : batsmen) {
            Batsman bat = (Batsman) batsmen1;
            System.out.println(bat.toString());
        }
    }
}

    

